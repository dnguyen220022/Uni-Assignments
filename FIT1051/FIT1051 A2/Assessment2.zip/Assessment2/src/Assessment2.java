public class Assessment2
{
    public static void main(String[] args)
    {
        System.out.println("Task 3 output: ");
        task3();

        System.out.println();
        System.out.println("Task 6 output: ");
        task6();

    }

    public static void task3()
    {

    }

    public static void task6()
    {

    }
}
