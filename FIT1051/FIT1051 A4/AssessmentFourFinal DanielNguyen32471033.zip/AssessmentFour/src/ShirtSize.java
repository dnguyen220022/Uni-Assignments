public enum ShirtSize
//shirtSize enum object, to standardize storage of shirt sizes
{
    S, M, L, XL
}
