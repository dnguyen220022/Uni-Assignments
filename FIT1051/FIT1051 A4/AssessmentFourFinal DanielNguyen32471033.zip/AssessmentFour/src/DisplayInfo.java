public interface DisplayInfo
    //interface for displayInfo method, which is used to print required information about various classes
{
    String displayInfo();
}
